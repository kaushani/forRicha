 package com.cg.capstore.UpdateDeliveryStatus.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.UpdateDeliveryStatus.entities.OrderDetails;
import com.cg.capstore.UpdateDeliveryStatus.repo.IUpdateDeliveryStatusRepo;
@Service
@Transactional
public class UpdateDeliveryStatusImpl implements IUpdateDeliveryStatusService{

	@Autowired
	IUpdateDeliveryStatusRepo IUpdateDeliveryStatusObj;
	@Override
	public boolean orderStatus(int orderId, String orderStatus)
	{
		OrderDetails orderDetailsObj= IUpdateDeliveryStatusObj.getOne(orderId);
		if(orderDetailsObj==null)
			return false;
		else
		{
			orderDetailsObj.setDeliveryStatus(orderStatus);
			IUpdateDeliveryStatusObj.save(orderDetailsObj);
			return true;
		}
	}
}
